from django.apps import AppConfig


class TareaormConfig(AppConfig):
    name = 'tareaorm'
